import React from "react";
import './Page.css'

function Page1(){


return(
    <>

    <div className = "Title">
        Title

    </div>

    </>

)


}


export default Page1;
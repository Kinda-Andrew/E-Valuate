import React from "react";

function Page2(){


return(
    <>

    <h1> Page 2 </h1>

    </>

)


}


export default Page2